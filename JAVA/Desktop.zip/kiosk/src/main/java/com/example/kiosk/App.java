package com.example.kiosk;

import com.example.kiosk.common.login.Login;

public class App
{
    public static void main( String[] args ) {

        Login login = new Login();
        
        login.login();
    }
}
